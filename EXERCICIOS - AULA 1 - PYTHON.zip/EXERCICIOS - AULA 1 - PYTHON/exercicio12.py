senha = input("Digite a senha: ")
if senha == "":
    print("Senha invalida")
elif senha == "1234":
    print("Acesso permetido")
else:
    print("Acesso negado")
    