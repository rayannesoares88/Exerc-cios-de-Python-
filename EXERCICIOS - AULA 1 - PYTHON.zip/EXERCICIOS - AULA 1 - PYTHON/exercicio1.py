metros = float(input("Digite o valor em metros: "))
centimetros = metros * 100

print("O valor em centimentros é: ", centimetros)
