lado = float(input("Digite o valor do lado: "))
area = lado ** 2
dobro = area * 2 

print("A area do quadrado é: ", area)
print("O dobro da area é: ", dobro)
