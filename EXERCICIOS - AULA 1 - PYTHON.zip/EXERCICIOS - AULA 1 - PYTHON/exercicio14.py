views = int(input("Digite a quantidade de visualizações: "))
if views <= 10000:
    total = 0 
elif views <= 100000:
    total = views * 0.02
elif views <= 1000000:
    total = views * 0.03
else:
    total = views * 0.05

if views > 500000:
    total += 500

print(f"Valor a receber: R${total:.2f}")
