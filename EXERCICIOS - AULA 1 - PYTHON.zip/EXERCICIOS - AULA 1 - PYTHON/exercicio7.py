num1 = int(input("Digite o primeiro numero inteiro: "))
num2 = int(input("Digite o segundo numero inteiro: "))
num3 = float(input("Digite um numero real: "))

resultado1 = (num1 * 2) * (num2 / 2)
resultado2 = (num1 * 3) + num3
resultado3 = num3 ** 3 

print("Resultado 1: ", resultado1)
print("Resultado 2: ", resultado2)
print("Resultado 3: ", resultado3)
