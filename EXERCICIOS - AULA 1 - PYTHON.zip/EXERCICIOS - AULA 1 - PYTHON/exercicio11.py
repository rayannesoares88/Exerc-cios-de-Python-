peso = float(input("Digite seu peso (kg): "))
altura = float(input("Digite sua altura (m): "))
imc = peso / (altura ** 2)

print("Seu IMC é: ", round(imc, 2))

if imc < 18.5:
    print("Classificação: Abaixo do peso")
elif 18.5 <= imc <= 24.9:
    print("Classificação: Sobrepeso")
elif imc >= 30:
    print("Classificação: Obesidade")
else:
    print("Classificação: Não definida nas regras")
    