valor_hora = float(input("Quanto voce ganha por hora? "))
horas_mes = float(input("Quantas horas voce trabalhou no mes? "))

salario = valor_hora * horas_mes
print("Seu salario no mes é: R$", salario)
