tipo = int(input("Digite o tipo de conta (1-comum, 2-premium): "))
saldo = float(input("Digite o saldo médio: "))

if tipo == 1:
    if saldo < 1000:
        tarifa = 25
    elif saldo <= 5000:
        tarifa = 25
        
elif tipo == 2: 
    if saldo < 5000:
        tarifa = 20
    else:
        tarifa = 0 
else:
    print("Tipo de conta invalido")
    tarifa = None
if tarifa is not None:
    print(f"Tarifa: R${tarifa:.2f}")
