altura = float(input("Digite sua altura: "))
sexo = input("Digite seu sexo (M para homem / F para mulher): ").upper()

if sexo == "M":
    peso_ideal1 = (72.7 * altura) - 58
elif sexo == "F":
    peso_ideal1 = (62.1 * altura) - 44.7
else:
    print("Sexo invalido!")    
    peso_ideal1 = None
if peso_ideal1 is not None:
    print("Seu peso ideal é: ", peso_ideal1, "kg")
