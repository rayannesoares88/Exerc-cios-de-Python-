nota_1 = float(input("Digite a nota 1:"))
nota_2 = float(input("Digite a nota 2:"))
media = ( nota_1 + nota_2) / 2 
print("Resultado", media)
if media >= 70:
    print("Aprovado")
elif media <40:
    print("Reprovado")
else:
    print("final")

