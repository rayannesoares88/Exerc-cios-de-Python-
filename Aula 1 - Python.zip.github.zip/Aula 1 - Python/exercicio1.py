raio = int(input("Escreva o valor do raio:"))
Pi = 3.14
c = 2 * Pi * raio
print("resultado:", c)