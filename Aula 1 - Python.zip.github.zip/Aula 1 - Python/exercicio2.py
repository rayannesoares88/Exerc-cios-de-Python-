lado = int(input("Escreva o valor da area:"))
area = lado * lado
print("resultado", area)