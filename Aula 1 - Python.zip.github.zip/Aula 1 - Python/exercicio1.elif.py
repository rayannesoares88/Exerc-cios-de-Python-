numero_da_conta = float(input("Numero da conta:"))
saldo = float(input("Digite o saldo:"))
valor_do_debito= float(input("Digite o valor em debito:"))
valor_do_credito = float(input("Digite o valor em credito:"))
saldo_atual = saldo - valor_do_debito + valor_do_credito
print("Resultado", saldo_atual)
if  saldo_atual >= 0:
    print("Saldo Positivo")
else: 
    print("Saldo Negativo")