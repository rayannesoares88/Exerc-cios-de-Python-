valor = float(input("Quanto você ganha por hora:"))
hora = int(input("Quantas horas você trabalha:"))
salario = (valor *  hora)
print(salario)
