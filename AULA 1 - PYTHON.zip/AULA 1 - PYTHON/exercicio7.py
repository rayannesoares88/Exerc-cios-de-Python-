num1 = int(input("Digite o primeiro número inteiro: "))
num2 = int(input("Digite o segundo número inteiro: "))
num3 = float(input("Digite um número real: "))

resultado1 = (num1 * 2) * (num2 / 2)
resultado2 = (num1 * 3) + num3
resultado3 = num3 ** 3

print("Produto do dobro do primeiro com metade do segundo:", resultado1)
print("Soma do triplo do primeiro com o terceiro:", resultado2)
print("Terceiro elevado ao cubo:", resultado3)