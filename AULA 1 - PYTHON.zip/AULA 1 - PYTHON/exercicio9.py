altura = float(input("Digite sua altura: "))
sexo = input("Digite M para homem ou F para mulher: ")

if sexo == "M":
    peso_ideal = (72.7 * altura) - 58
    print("Peso ideal:", peso_ideal)

elif sexo == "F":
    peso_ideal = (62.1 * altura) - 44.7
    print("Peso ideal:", peso_ideal)

else:
    print("Sexo inválido")