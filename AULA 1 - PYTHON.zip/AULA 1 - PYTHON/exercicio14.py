visualizacoes = int(input("Digite a quantidade de visualizações: "))

valor = 0

if visualizacoes <= 10000:
    valor = 0

elif visualizacoes <= 100000:
    valor = visualizacoes * 0.02

elif visualizacoes <= 1000000:
    valor = visualizacoes * 0.03

else:
    valor = visualizacoes * 0.05

# bônus
if visualizacoes > 500000:
    valor += 500

print("Valor total a receber: R$", valor)