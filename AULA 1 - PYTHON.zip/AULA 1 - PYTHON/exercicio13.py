tipo_conta = int(input("Digite o tipo da conta (1-Comum / 2-Premium): "))
saldo = float(input("Digite o saldo médio: "))

tarifa = 0

if tipo_conta == 1:

    if saldo < 1000:
        tarifa = 25

    elif saldo <= 5000:
        tarifa = 15

    else:
        tarifa = 0

elif tipo_conta == 2:

    if saldo < 5000:
        tarifa = 20

    else:
        tarifa = 0

print("Tarifa a ser cobrada: R$", tarifa)