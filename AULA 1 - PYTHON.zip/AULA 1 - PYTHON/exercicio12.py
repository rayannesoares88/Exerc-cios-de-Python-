senha = input("Digite a senha: ")

if senha == "":
    print("Senha inválida")

elif senha == "1234":
    print("Acesso permitido")

else:
    print("Acesso negado")