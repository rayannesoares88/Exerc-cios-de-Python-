valor_hora = float(input("Quanto você ganha por hora? "))
horas_mes = float(input("Quantas horas trabalhou no mês? "))

salario = valor_hora * horas_mes

print("Salário do mês: R$", salario)